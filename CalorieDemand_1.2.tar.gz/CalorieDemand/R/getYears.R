getYears <- function(x) return(as.integer(substring(dimnames(x)[[2]], 2)))
